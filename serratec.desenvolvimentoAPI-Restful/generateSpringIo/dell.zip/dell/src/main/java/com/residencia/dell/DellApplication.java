package com.residencia.dell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DellApplication {

	public static void main(String[] args) {
		SpringApplication.run(DellApplication.class, args);
	}

}
